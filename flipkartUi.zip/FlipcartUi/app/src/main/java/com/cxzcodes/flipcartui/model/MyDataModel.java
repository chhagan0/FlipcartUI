package com.cxzcodes.flipcartui.model;


public class MyDataModel {
    private String name;
    private String price;
    private int imageResId;

    public MyDataModel(String name,String price, int imageResId) {
        this.price = price;
        this.name = name;
        this.imageResId = imageResId;
    }

    public String getName() {
        return name;
    }
    public String getPrice() {
        return price;
    }

    public int getImageResId() {
        return imageResId;
    }
}

